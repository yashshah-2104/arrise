variable "bucket_name" {
  type    = string
  default = "arrise-shared-data-111111111111"
}

# fix 1: roleB is a role, not a user - original had arn:..:user/roleB which is wrong
resource "aws_iam_role" "roleC" {
  name = "roleC"
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Action    = "sts:AssumeRole"
      Principal = { AWS = "arn:aws:iam::000000000000:role/roleB" }
    }]
  })
}

# fix 2: original had Resource = "*" which gives access to every bucket in the account
# scoped to just the one bucket instead
resource "aws_iam_role_policy" "roleC_s3" {
  name = "roleC-s3-access"
  role = aws_iam_role.roleC.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect   = "Allow"
      Action   = "s3:*"
      Resource = [
        "arn:aws:s3:::${var.bucket_name}",
        "arn:aws:s3:::${var.bucket_name}/*"
      ]
    }]
  })
}
