# NOTES

account A = 000000000000, account B = 111111111111
bucket/repo/cluster/service names are placeholders, replace before running

---

## task 1 - EC2 module

used a single `instances` map variable so all 5 instances come from one place. added a new map entry = new instance, no copy-pasting resource blocks.

had to split into two `aws_instance` resource blocks (standard and protected) because terraform won't let you pass `prevent_destroy` as a variable, it needs to be a literal true/false in the code. both blocks still use for_each so it's still driven by the map.

chose `db` as the protected one. it's on r5.large with a 100GB io2 volume. the other 4 (web, app, worker, cache) are stateless enough that you can rebuild them from the AMI if something goes wrong. the database is the one thing you can't just recreate - if terraform deletes it, the data is gone. prevent_destroy makes terraform refuse to delete it instead of proceeding. it only covers terraform though - manual console deletes need EC2 termination protection separately.

io1 on cache, io2 on db. all 5 instances tagged Name/Environment/Owner.

---

## task 2 - remote state + locking

without a backend, state is just a file on your laptop. two people running apply at the same time = two separate state files, neither knows what the other is doing. you can get duplicate resources, or if you share the file on a network drive/git two concurrent writes corrupt it and last write wins. resources end up in AWS but gone from state.

S3 + DynamoDB fixes this:
- one copy of state in S3, versioned and encrypted
- terraform does a conditional write to DynamoDB before any plan/apply - only one can succeed, second person gets a lock error with who holds it and since when
- lock releases when the run finishes, or `terraform force-unlock <id>` if it crashes
- versioning means you can recover a corrupted state file

---

## task 3 - IAM

group1 = engine + ci, programmatic/CLI only. only permission is to assume roleB.
group2 = alice + bob, full console + CLI. can assume roleA or roleB.

roleA trusts alice and bob. policy uses NotAction iam:* to allow everything except IAM, plus an explicit Deny iam:* as a fallback in case another policy gets attached to the role later.

roleB trusts engine only. its only permission is sts:AssumeRole on roleC in account B. ci is in group1 but has no reason to touch account B so left it out of roleB's trust.

roleC in account B trusts exactly arn:aws:iam::000000000000:role/roleB and nothing else. S3 policy is s3:* on one bucket - needs both the bucket ARN and bucket/* because bucket-level actions and object-level actions match on different resource ARN patterns.

apply account-a first so roleB exists when account-b references its ARN.

### would I use IAM users with long-lived access keys in prod?

no. access keys don't expire and they end up everywhere - .env files, CI config, laptops, git history. you often don't know one leaked until something breaks.

for ci: OIDC federation. github actions / gitlab both support AssumeRoleWithWebIdentity and the pipeline gets short-lived creds scoped to a repo + branch, nothing stored. if CI runs inside AWS already (codebuild etc) just use a service role.

for engine: if it's a person, IAM Identity Center + MFA. if it's a workload, instance profile or task role.

if a key is unavoidable for some reason - old tool with no role support - at least scope the policy tightly, store in Secrets Manager, rotate every 90 days, add an IP condition if possible and alert on API calls.

### trust policy - roleB ARN vs account A root?

trusting the account root (arn:aws:iam::000000000000:root) means account B is delegating the access decision to account A. anyone in account A that account A's admins allow to call AssumeRole on roleC can get in - roleA, future roles, whatever. account B loses control.

trusting roleB's specific ARN means account B decides. only roleB matches, account A admins can't extend that to anything else because the check is in account B's trust policy.

also worth knowing: IAM stores the principal as roleB's internal unique ID, not the ARN text. if roleB gets deleted and recreated with the same name the trust won't match the new role, you'd need to re-apply the trust policy. not a problem day to day but good to know before rotating roles.

---

## task 4 - ci policy

policy file: task4-ci-policy/ci-policy.json

for ECR: the login token action (GetAuthorizationToken) has to use Resource * because AWS doesn't support scoping it to a specific repo - that's just how the API works. the actual push actions are all scoped to one repo ARN.

for ECS: RegisterTaskDefinition and DescribeTaskDefinition don't support resource-level restrictions at all, so those stay on *. UpdateService and DescribeServices are locked to the one service. I also added iam:PassRole on the two task roles only - without it ECS rejects the task definition registration. the condition makes sure it can only be passed to ECS, not anything else.

for S3: read only - ListBucket on the bucket and GetObject on the objects. needs two separate statements because bucket-level and object-level actions need different resource ARN formats.

what I left out and why:
- ECR pull actions - pipeline only pushes images, doesn't pull them
- ECR repo create/delete - not CI's job
- s3:PutObject / DeleteObject - requirement says read only
- ECS create/delete/run/stop - a deploy only needs UpdateService, nothing else
- iam:PassRole on * - classic privilege escalation, locked to 2 specific roles
- no wildcard actions, no AWS managed policies

---

## task 5 - bugs

fixed version: task5-fix/fixed.tf

**bug 1 - principal ARN has user/roleB instead of role/roleB**

roleB is a role not a user. the ARN type matters - IAM resolves principals to internal IDs when saving a trust policy and there's no user called roleB, so it throws MalformedPolicyDocument and the apply fails. even if a user named roleB existed, the policy would trust the user not the role so it still wouldn't work. fix: change user/roleB to role/roleB.

**bug 2 - Resource = "*" on s3:***

this one doesn't error, it applies fine. that's the problem. s3:* on * gives roleC access to every bucket in account B, not just the intended one. silent over-permissioning. fix is to scope to just the bucket: need both the bucket ARN (for bucket-level actions like ListBucket) and bucket/* (for object-level actions like GetObject/PutObject). using only bucket/* leaves ListBucket without a matching resource.
