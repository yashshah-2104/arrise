terraform {
  required_version = ">= 1.3.0"
  required_providers {
    aws = { source = "hashicorp/aws", version = "~> 5.0" }
  }
}

provider "aws" {
  region  = "us-east-1"
  profile = "account-a"
}

variable "account_b_id" {
  type    = string
  default = "111111111111"
}

# users
resource "aws_iam_user" "engine" { name = "engine" }
resource "aws_iam_user" "ci"     { name = "ci" }
resource "aws_iam_user" "alice"  { name = "alice" }
resource "aws_iam_user" "bob"    { name = "bob" }

# groups
resource "aws_iam_group" "group1" { name = "group1" }
resource "aws_iam_group" "group2" { name = "group2" }

resource "aws_iam_group_membership" "group1" {
  name  = "group1-membership"
  group = aws_iam_group.group1.name
  users = [aws_iam_user.engine.name, aws_iam_user.ci.name]
}

resource "aws_iam_group_membership" "group2" {
  name  = "group2-membership"
  group = aws_iam_group.group2.name
  users = [aws_iam_user.alice.name, aws_iam_user.bob.name]
}

# group1 can only call sts:AssumeRole on roleB
resource "aws_iam_group_policy" "group1_policy" {
  name  = "group1-assume-roleB"
  group = aws_iam_group.group1.name
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect   = "Allow"
      Action   = "sts:AssumeRole"
      Resource = aws_iam_role.roleB.arn
    }]
  })
}

# group2 can assume roleA or roleB
resource "aws_iam_group_policy" "group2_policy" {
  name  = "group2-assume-roles"
  group = aws_iam_group.group2.name
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect   = "Allow"
      Action   = "sts:AssumeRole"
      Resource = [aws_iam_role.roleA.arn, aws_iam_role.roleB.arn]
    }]
  })
}

# roleA - admin on all services except IAM
# alice and bob can assume it
resource "aws_iam_role" "roleA" {
  name = "roleA"
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Action    = "sts:AssumeRole"
      Principal = { AWS = [aws_iam_user.alice.arn, aws_iam_user.bob.arn] }
    }]
  })
}

resource "aws_iam_role_policy" "roleA_policy" {
  name = "admin-except-iam"
  role = aws_iam_role.roleA.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect    = "Allow"
        NotAction = "iam:*"
        Resource  = "*"
      },
      {
        # deny IAM explicitly so it stays blocked even if another policy is attached later
        Effect   = "Deny"
        Action   = "iam:*"
        Resource = "*"
      }
    ]
  })
}

# roleB - only engine can assume it
# its only permission is to assume roleC in account B
resource "aws_iam_role" "roleB" {
  name = "roleB"
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Action    = "sts:AssumeRole"
      Principal = { AWS = aws_iam_user.engine.arn }
    }]
  })
}

resource "aws_iam_role_policy" "roleB_policy" {
  name = "assume-roleC"
  role = aws_iam_role.roleB.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect   = "Allow"
      Action   = "sts:AssumeRole"
      Resource = "arn:aws:iam::${var.account_b_id}:role/roleC"
    }]
  })
}
