terraform {
  required_version = ">= 1.3.0"
  required_providers {
    aws = { source = "hashicorp/aws", version = "~> 5.0" }
  }
}

provider "aws" {
  region  = "us-east-1"
  profile = "account-b"
}

variable "account_a_id" {
  type    = string
  default = "000000000000"
}

# roleC - only roleB from account A can assume it (not the whole account A root)
resource "aws_iam_role" "roleC" {
  name = "roleC"
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Action    = "sts:AssumeRole"
      Principal = { AWS = "arn:aws:iam::${var.account_a_id}:role/roleB" }
    }]
  })
}

# full s3 access to one bucket only
# needs both ARNs: bucket ARN for bucket-level actions, bucket/* for object-level actions
resource "aws_iam_role_policy" "roleC_s3" {
  name = "roleC-s3-access"
  role = aws_iam_role.roleC.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect   = "Allow"
      Action   = "s3:*"
      Resource = [
        "arn:aws:s3:::arrise-shared-data-111111111111",
        "arn:aws:s3:::arrise-shared-data-111111111111/*"
      ]
    }]
  })
}
