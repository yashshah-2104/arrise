# devops assignment

## folder structure

| folder | what's in it |
|---|---|
| `task1-2-ec2/` | EC2 module (task 1) + S3 backend config (task 2) |
| `task3-iam/account-a/` | users, groups, roleA, roleB |
| `task3-iam/account-b/` | roleC |
| `task4-ci-policy/ci-policy.json` | least-privilege policy for ci |
| `task5-fix/fixed.tf` | corrected version of the broken snippet |
| `NOTES.md` | written answers for all tasks |

## how to run

1. EC2 instances:
   ```
   cd task1-2-ec2
   terraform init && terraform apply
   ```

2. account A IAM:
   ```
   cd task3-iam/account-a
   terraform init && terraform apply
   ```

3. account B IAM (run account-a first so roleB exists):
   ```
   cd ../account-b
   terraform init && terraform apply
   ```
