variable "region" {
  type    = string
  default = "us-east-1"
}

variable "environment" {
  type    = string
  default = "dev"
}

variable "owner" {
  type    = string
  default = "yash-shah"
}

variable "instances" {
  type = map(object({
    instance_type = string
    volume_type   = string
    volume_size   = number
    key_name      = string
    iops          = optional(number)
    protected     = optional(bool, false)
  }))

  default = {
    web = {
      instance_type = "t3.micro"
      volume_type   = "gp3"
      volume_size   = 20
      key_name      = "key-web"
    }
    app = {
      instance_type = "t3.small"
      volume_type   = "gp2"
      volume_size   = 30
      key_name      = "key-app"
    }
    worker = {
      instance_type = "t3.medium"
      volume_type   = "standard"
      volume_size   = 50
      key_name      = "key-worker"
    }
    cache = {
      instance_type = "m5.large"
      volume_type   = "io1"
      volume_size   = 50
      iops          = 2000
      key_name      = "key-cache"
    }
    db = {
      instance_type = "r5.large"
      volume_type   = "io2"
      volume_size   = 100
      iops          = 3000
      key_name      = "key-db"
      protected     = true
    }
  }
}
