# task 2 - s3 backend for remote state + dynamodb for locking
# backend values can't be variables so they're hardcoded here
terraform {
  backend "s3" {
    bucket         = "arrise-devops-tfstate-000000000000"
    key            = "task1/instances/terraform.tfstate"
    region         = "us-east-1"
    dynamodb_table = "terraform-state-locks"
    encrypt        = true
  }
}
