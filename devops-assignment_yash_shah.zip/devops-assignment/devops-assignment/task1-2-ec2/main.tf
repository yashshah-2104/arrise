provider "aws" {
  region = var.region
}

module "instances" {
  source = "./modules/instances"

  instances   = var.instances
  environment = var.environment
  owner       = var.owner
}
