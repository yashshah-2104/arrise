output "instance_ids" {
  value = module.instances.instance_ids
}

output "private_ips" {
  value = module.instances.private_ips
}
