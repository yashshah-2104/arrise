output "instance_ids" {
  description = "map of instance name to instance ID"
  value = merge(
    { for k, i in aws_instance.standard : k => i.id },
    { for k, i in aws_instance.protected : k => i.id }
  )
}

output "private_ips" {
  description = "map of instance name to private IP"
  value = merge(
    { for k, i in aws_instance.standard : k => i.private_ip },
    { for k, i in aws_instance.protected : k => i.private_ip }
  )
}
