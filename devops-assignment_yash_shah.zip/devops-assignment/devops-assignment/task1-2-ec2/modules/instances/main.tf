data "aws_ssm_parameter" "al2023" {
  name = "/aws/service/ami-amazon-linux-latest/al2023-ami-kernel-default-x86_64"
}

locals {
  common_tags = {
    Environment = var.environment
    Owner       = var.owner
  }

  # split so we can put prevent_destroy = true on the protected instance.
  # terraform requires it to be a literal - you can't pass it as a variable.
  standard_instances  = { for k, v in var.instances : k => v if !v.protected }
  protected_instances = { for k, v in var.instances : k => v if v.protected }
}

resource "aws_instance" "standard" {
  for_each = local.standard_instances

  ami           = data.aws_ssm_parameter.al2023.value
  instance_type = each.value.instance_type
  key_name      = each.value.key_name

  root_block_device {
    volume_type = each.value.volume_type
    volume_size = each.value.volume_size
    iops        = contains(["io1", "io2"], each.value.volume_type) ? each.value.iops : null
  }

  tags = merge(local.common_tags, { Name = "${var.environment}-${each.key}" })
}

resource "aws_instance" "protected" {
  for_each = local.protected_instances

  ami           = data.aws_ssm_parameter.al2023.value
  instance_type = each.value.instance_type
  key_name      = each.value.key_name

  root_block_device {
    volume_type = each.value.volume_type
    volume_size = each.value.volume_size
    iops        = contains(["io1", "io2"], each.value.volume_type) ? each.value.iops : null
  }

  tags = merge(local.common_tags, { Name = "${var.environment}-${each.key}" })

  lifecycle {
    prevent_destroy = true
  }
}
