variable "instances" {
  description = "map of instance name to settings - one entry per EC2 instance"
  type = map(object({
    instance_type = string
    volume_type   = string           # gp2, gp3, io1, io2, standard
    volume_size   = number           # size in GiB
    key_name      = string           # key pair must already exist in the region
    iops          = optional(number) # needed if volume_type is io1 or io2
    protected     = optional(bool, false)
  }))
}

variable "environment" {
  description = "env tag"
  type        = string
}

variable "owner" {
  description = "owner tag"
  type        = string
}
